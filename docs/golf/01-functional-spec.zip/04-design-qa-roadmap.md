# 04. 디자인 시스템 · QA/접근성 · 로드맵/리스크

---

## 1. 디자인 시스템 (CI 통일)

오마이트립 본 서비스 CI와 **동일**하게 맞춤. 토큰: `src/styles/ohmygolf.css`(`.ohmygolf` 스코프).

### 1.1 컬러
| 토큰 | 값 | 용도 |
|---|---|---|
| `--g-forest` | **#ef7f29** | Primary(OMT 오렌지) — CTA/활성/강조 |
| `--g-forest-600` | #e06f1c | hover |
| `--g-green` / `--g-success` | #008f42 | 포함/성공 |
| `--g-ivory` | #f5f5f5 | 보조 서페이스 |
| `--g-charcoal` / `-60` / `-40` | #222 / #666 / #999 | 텍스트 |
| `--g-line` / `-soft` | #e5e5e5 / #efefef | 보더 |
| `--g-danger` | #ff3b30 | 경고 |

### 1.2 타이포 / 형태
- 폰트: **Pretendard** (`--g-serif`/`--g-sans` 동일 지정)
- radius: 10 / 15 / 20 / pill(999)
- 그림자: xs~lg (OMT 스타일 5px offset 계열)
- 헤더 높이: 74px(기본) / 60px(compact)
- 컨테이너 max: 1240px

### 1.3 주요 컴포넌트 (재사용)
`PackageCard · SearchBox(hero/compact) · GolfDestPopover · GolfRangeCalendar · FilterControls · CompareTray · CourseInfoSection · ItinerarySection · common/ui(StarRating·ReviewScore·WishlistButton·CompareButton·Modal·BottomSheet·EmptyState·CardSkeleton)`

### 1.4 격리
`GolfShell`이 마운트 시 body 클래스 `omt-desktop/omt-mobile` 제거 → `ohmygolf-body` 부여, 언마운트 시 복원. 모든 골프 스타일 `.ohmygolf …` 스코프 → **OMT 클론과 상호 무간섭**(검증됨).

---

## 2. QA / 접근성 현황 (실측)

**자동 스윕**(`scripts/golf-qa.mjs`, 1440×900 + 모바일) — 11개 페이지:

| 지표 | 결과 |
|---|---|
| 콘솔 에러 | **0** (전 페이지) |
| 깨진 이미지(4xx / naturalWidth 0) | **0** |
| img alt 누락 | **0** |
| 버튼 라벨 누락(text/aria/title) | **0** |
| 페이지당 h1 | **1** (전 페이지) |
| 가로 오버플로 | **없음** (데스크톱·모바일) |
| 엣지케이스 | 비교 3/3 제한·4번째 비활성 / 빈 입력 진행 차단 / 매진 티타임 처리 ✔ |
| 유닛 테스트 | 24 통과 |
| 빌드 | 118 페이지 정적 생성 성공 |

**접근성**: 키보드 갤러리(Enter 열기/Esc 닫기), 시맨틱 h1/section, aria-label, 포커스 이동. 미검증: 스크린리더 실사용 전수, 색대비 전수(주 색상은 통과), 다크모드 미지원.

### 점수 (2026-07-29)
| 구분 | 점수 | 캡 요인 |
|---|---|---|
| **QA 품질** | **94/100** | 오프토픽 스톡 이미지(시각완성도) |
| **종합 기획(제품)** | **89/100** | 실재고·결제·회원·ELLIS 미연동(목데이터) |
| **순수 시연물** | **97/100** | 실백엔드·이미지 |

---

## 3. 로드맵

### 지금(코드로 가능, 자료 불필요)
- [ ] **이미지 정합성** — CC 풀에서 골프 무관 이미지 제거/큐레이션(→ QA 시각점수 즉시 상승)
- [ ] 분석 이벤트 설계(퍼널 훅 자리)
- [ ] 콘텐츠 카피 다듬기

### 실데이터·시스템 필요 ([03 문서])
- [ ] 골프장 마스터 + 상품 실데이터(ELLIS 스키마)
- [ ] 티타임/재고 조회 + 가격 확정
- [ ] 결제(PG) + 예약 생성 + 마이트립 연동
- [ ] 회원 SSO
- [ ] 실사진·다국어·실시간 환율

---

## 4. 리스크 / 이슈

| 리스크 | 영향 | 대응 |
|---|---|---|
| 오프토픽 스톡 이미지 | 신뢰도·시연 인상 | 실사진 확보 전까지 큐레이션된 골프 이미지로 교체 |
| 정적 export vs 실시간 재고 | 티타임·가격 최신성 | CSR fetch 또는 SSR/ISR 전환 |
| 티타임 재고 트랜잭션 | 오버부킹 | 홀드/확정 로직 + 파트너 API SLA |
| 현지 결제 항목(카트/캐디) | 가격 오해·클레임 | 표기·정산 정책 확정, ‘현지 결제’ 명확 고지(현재 반영) |
| 비골퍼 요금 규칙(현재 0.6 가정) | 가격 정확성 | 정책 확정 필요 |
| 콘텐츠 미번역 | 글로벌 사용성 | 상품/블로그 다국어화 |

---

## 5. 기획팀 의사결정 필요 (요약)

1. **골프텔 카테고리 정식 채택 여부**
2. **소싱 모델**: 직접 계약 vs 제휴(현지 파트너), 티타임 실시간 vs 요청형
3. **가격 정책**: 1인 패키지가 구조, 현지 결제 항목 표기·정산, 비골퍼 요금
4. **ELLIS 골프텔 스키마 신설 범위**([03 §3])
5. **브랜드/도메인**: OHMYGOLF vs 오마이트립 서브카테고리
6. **콘텐츠 전략**: 블로그 운영 주체·번역 범위

---

## 6. 참고 링크

- 라이브: https://bstars00-rgb.github.io/OHMYTRIP/golf/
- 코드: `src/{app,components,features,mocks}/golf`, `src/styles/ohmygolf*.css`
- 롤백/구조: `docs/ohmygolf-prototype.md`
- QA 스크립트: `scripts/golf-qa.mjs`
